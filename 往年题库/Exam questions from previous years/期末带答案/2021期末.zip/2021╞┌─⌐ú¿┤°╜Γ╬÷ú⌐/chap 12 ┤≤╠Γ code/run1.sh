gcc -o producer-consumer-solution-1 producer-consumer-solution-1.c csapp.c -lpthread
./producer-consumer-solution-1
rm producer-consumer-solution-1