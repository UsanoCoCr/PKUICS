gcc -o producer-consumer-solution-2 producer-consumer-solution-2.c csapp.c -lpthread
./producer-consumer-solution-2
rm producer-consumer-solution-2