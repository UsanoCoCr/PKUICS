gcc -o producer-consumer-solution-2-strong-test producer-consumer-solution-2-strong-test.c csapp.c -lpthread
./producer-consumer-solution-2-strong-test
rm producer-consumer-solution-2-strong-test